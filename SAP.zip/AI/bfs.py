#breadth_first_tree_search
from collections import deque
infinity = float('inf')

class Node:
    def __init__(self, state, parent=None, action=None, path_cost=0):
        self.state = state
        self.parent = parent
        self.action = action
        self.path_cost = path_cost
        self.depth = 0
        if parent:
            self.depth = parent.depth + 1

    def __repr__(self):  # To print Node Object
        return "<Node "+self.state+" >"

    def expand(self, problem):  # To extract Children
        return (Node(action, self, action, problem.path_cost(self.path_cost, self.state, action)) for action in problem.actions(self.state))

    def solution(self):
        return [node.state for node in self.path()]

    def path(self):  # extracts the path of any starting node from current to source
        node, path_back = self, []
        while node:
            path_back.append(node)
            node = node.parent
        return list(reversed(path_back))  # order changed to show from source to current

class GraphProblem():
    def __init__(self, initial, goal, graph):
        self.graph = graph
        self.initial = initial
        self.goal = goal

    def goal_test(self, state):
        return state == self.goal

    def actions(self, A):
        return list(self.graph.get(A).keys())

    def path_cost(self, cost_so_far, A,  B):
        return cost_so_far + (self.graph.get(A, B) or infinity)


class Graph:
    def __init__(self, graph_dict=None, directed=True):
        self.graph_dict = graph_dict or {}
        self.directed = directed

    def get(self, a, b=None):
        if b is None:
            return self.graph_dict.get(a)
        else:
            return self.graph_dict.get(a).get(b)

    def nodes(self):
        return list(self.graph_dict.keys())


def breadth_first_tree_search(problem):  # our algorithm
    frontier = deque([Node(problem.initial)])
    print("Search begins from : ", frontier)
    while frontier:
        node = frontier.popleft()
        print("Now Exploring...", node)
        if problem.goal_test(node.state):
            return node
        x = node.expand(problem)
        print("Expanded Nodes : ", x)
        frontier.extend(x)
    return None

romania_map = Graph(
    {
        'Arad': {'Sibiu': 140, 'Zerind': 75, 'Timisoara': 118},
        'Zerind': {'Arad': 75, 'Oradea': 71},
        'Oradea': {'Zerind': 71, 'Sibiu': 151},
        'Sibiu': {'Arad': 140, 'Oradea': 151, 'Fagaras': 99, 'Rimnicu': 80},
        'Timisoara': {'Arad': 118, 'Lugoj': 111},
        'Lugoj': {'Timisoara': 111, 'Mehadia': 70},
        'Mehadia': {'Lugoj': 70, 'Drobeta': 75},
        'Drobeta': {'Mehadia': 75, 'Craiova': 120},
        'Craiova': {'Drobeta': 120, 'Rimnicu': 146, 'Pitesti': 138},
        'Rimnicu': {'Sibiu': 80, 'Craiova': 146, 'Pitesti': 97},
        'Fagaras': {'Sibiu': 99, 'Bucharest': 211},
        'Pitesti': {'Rimnicu': 97, 'Craiova': 138, 'Bucharest': 106},
        'Bucharest': {'Fagaras': 211, 'Pitesti': 101, 'Giurgiu': 90, 'Urziceni': 85},
        'Giurgiu': {'Bucharest': 90},
        'Urziceni': {'Bucharest': 85, 'Vaslui': 142, 'Hirsova': 86},
        'Hirsova': {'Urziceni': 98, 'Eforie': 86},
        'Eforie': {'Hirsova': 86},
        'Vaslui': {'Iasi': 92, 'Urziceni': 142},
        'Iasi': {'Vaslui': 92, 'Neamt': 87},
        'Neamt': {'Iasi': 87}
    },False
)

romania_problem = GraphProblem('Arad', 'Neamt', romania_map)
final_node = breadth_first_tree_search(romania_problem)
print("\nSolution of ", romania_problem.initial, "to", romania_problem.goal)
print("\nPath Cost of Final Node : ", final_node.path_cost)
print(final_node.solution())