#iterative_deepening_search
from collections import deque
import sys 
infinity=float('inf')

class Node:
    def __init__(self,state,parent=None,action=None,path_cost=0):
        self.state=state
        self.parent=parent
        self.action=action
        self.path_cost=path_cost
        self.depth=0
        if parent:
            self.depth=parent.depth + 1
    def __repr__(self):
        return"< Node{} >".format(self.state)

    def expand(self,problem):
        return [self.child_node(problem,action)for action in problem.action(self.state)]
    
    def child_node(self,problem,action):
        next_state = problem.result(self.state,action)
        next_node = Node(next_state,self,action,problem.path_cost(self.path_cost,self.state,action,next_state))
        return next_node
    
    def solution(self):
        return[node.state for node in self.path()[1:]]
    
    def path(self):
        node,path_back = self,[]
        while node:
            path_back.append(node)
            node = node.parent
        return list(reversed(path_back))

class Graph:
    def __init__(self,graph_dict=None,directed=True):
        self.graph_dict = graph_dict or{}
        self.directed = directed
        if not directed:
            self.make_undirected()

    def make_undirected(self):
        for a in list(self.graph_dict.keys()):
           ## print("processing node...",a)
            for(b,dist)in self.graph_dict[a].items():
                self.connect1(b,a,dist)

    def connect1(self , A ,B , distance) :
        self.graph_dict.setdefault(A, {}) [B] = distance

    def get(self,a,b=None):
        links = self.graph_dict.setdefault(a,{})
        if b is None:
            return links
        else:
            return links.get(b)
           

    def nodes(self):
        nodelist = list()
        for key in self.graph_dict.keys():
            nodelist.append(key)
            return nodelist

def UndirectedGraph(graph_dict=None):
    return Graph(graph_dict = graph_dict,directed=False)

def breadth_first_tree_search(problem):
    frontier = deque([Node(problem.initial)])
    print("Search beins from :",frontier)
    while frontier:
        node = frontier.popleft()
        print("Now exploring...",node)
        if problem.goal_test(node.state):
            return node
        x = node.expand(problem)
        print("Expanding Nodes :",x)
        frontier.extend(x)
    return None

class Problem(object):

    def __init__(self,initial,goal=None):
        self.initial = initial
        self.goal = goal

    def action(self,state):
        raise NotImplementedError

    def result(self,state,action):
        raise NotImplementedError

    def goal_test(self,state):
        if isinstance(self.goal,list):
            return is_in(state, self.goal)
        else:
            return state == self.goal
        
    def path_cost(self,c,state1,action,state2):
        return c+1

    def value(self,state):
        raise NotImplementedError


def UndirectedGraph(graph_dict=None):
    return Graph(graph_dict = graph_dict,directed=False)

class GraphProblem(Problem):
    def __init__(self,initial,goal,graph):
        Problem.__init__(self,initial,goal)
        self.graph = graph

    def action(self,A):
        return list(self.graph.get(A).keys())

    def result(self,state,action):
        return action

    def path_cost(self,cost_so_far,A,action,B):
        return cost_so_far + (self.graph.get(A,B) or infinity)

def depth_limited_search(problem, limit = 50):
    def recursive_dis(node, problem, limit):
        if problem.goal_test(node.state):
            return node
        elif limit == 0:
            return 'cutoff'
        else:
            cutoff_occurred = False
            for child in node.expand(problem):
                result = recursive_dis(child, problem, limit - 1)
                if result == 'cutoff':
                    cutoff_occurred = True
                elif result is not None:
                    return result
            return 'cutoff' if cutoff_occurred else 'Not found'
    return recursive_dis(Node(problem.initial),problem,limit)

def iterative_deepening_search(problem, limit):
    for depth in range(0,limit):
        print("checking with depth : ", depth)
        result = depth_limited_search(problem, depth)
        print("result:", result)
    return result

class GraphProblem(Problem):
    def __init__(self,initial,goal,graph):
        Problem.__init__(self,initial,goal)
        self.graph = graph

    def action(self,A):
        return list(self.graph.get(A).keys())

    def result(self,state,action):
        return action

    def path_cost(self,cost_so_far,A,action,B):
        return cost_so_far + (self.graph.get(A,B) or infinity)

romania_map = UndirectedGraph(
            {'Arad':{'Zerind':75,'Sibiu':140,'Timisoara':118},
            'Zerind':{'Arad':75,'Oradea':71},
            'Timisoara':{'Lugoj':111,'Arad':118},
            'Lugoj':{'Timisoara':111,'Mehadia':70},
            'Mehadia':{'Lugoj':70,'Drobeta':75},
            'Drobeta':{'Mehadia':75,'Craiova':120},
             'Oradea':{'Zerind':71,'Sibiu':151},
             'Sibiu':{'Oradea':151,'Arad':140,'Rimmico Vilcea':80,'Fagaras':99},
             'Rimmico Vilcea':{'Sibiu':80,'Pitesti':97,'Craiova':146},
             'Pitesti':{'Rimmico Vilcea':97,'Craiova':138,'Bucharest':101},
             'Craiova':{'Rimmico Vilcea':146,'Pitesti':138,'Drobeta':120},
             'Fagaras':{'Sibiu':99,'Bucharest':211},
             'Bucharest':{'Fagaras':211,'Urziceni':85,'Giurgiu':90},
             'Giurgiu':{'Bucharest':90},
             'Urziceni':{'Bucharest':85,'Hirsova':85,'Vaslui':142},
             'Hirsova':{'Urziceni':98,'Eforie':86},
             'Eforie':{'Hirsova':86},
             'Vaslui':{'Urzicenl':142,'Iasi':92},
             'Iasi':{'Neamt':87,'Vaslui':92},
             'Neamt':{'Iasi':87}}
            )

romania_problem = GraphProblem('Arad','Timisoara',romania_map)

finalnode = iterative_deepening_search(romania_problem, 5)
print("solution of", romania_problem.initial," to ", romania_problem.goal,finalnode.solution())

print("path cost of final node = ", finalnode.path_cost)